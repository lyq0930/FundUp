CREATE TRIGGER EnoughFundForProject
BEFORE UPDATE ON Project
FOR EACH ROW
  begin
    if new.pstatus != 'Completed' and new.fundSoFar >= new.maxFund
    then set new.pstatus = 'Funded, in progessing';
      update Fund F
      set moneyStatus = 'Released'
      where F.pid = new.pid;
    end if;
  end;
