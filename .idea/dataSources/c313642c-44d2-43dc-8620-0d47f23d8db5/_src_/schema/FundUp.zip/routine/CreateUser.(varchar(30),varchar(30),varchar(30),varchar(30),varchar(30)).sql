CREATE PROCEDURE CreateUser(IN userNameIn VARCHAR(30), IN userPassIn VARCHAR(30), IN fullNameIn VARCHAR(30),
                            IN emailIn    VARCHAR(30), IN phoneIn VARCHAR(30))
  BEGIN
    insert into Users(username, userpass, fullName, email, phoneNum) values (userNameIn, userPassIn, fullNameIn, emailIn, phoneIn);
  END;
