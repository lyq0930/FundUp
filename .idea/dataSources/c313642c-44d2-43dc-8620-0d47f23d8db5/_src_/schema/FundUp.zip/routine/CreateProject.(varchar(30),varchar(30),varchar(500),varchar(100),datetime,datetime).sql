CREATE PROCEDURE CreateProject(IN usernameIn VARCHAR(30), IN pnameIn VARCHAR(30), IN pdescriptionIn VARCHAR(500),
                               IN tagsIn     VARCHAR(100), IN endFundTimeIn DATETIME, IN completionDateIn DATETIME)
  BEGIN
    insert into Project(pname, pdescription, pOwner, tags, endFundTime, completionDate, pstatus)
    values (pnameIn, pdescriptionIn, usernameIn, tagsIn, endFundTimeIn, completionDateIn, 'Funding');
  END;
