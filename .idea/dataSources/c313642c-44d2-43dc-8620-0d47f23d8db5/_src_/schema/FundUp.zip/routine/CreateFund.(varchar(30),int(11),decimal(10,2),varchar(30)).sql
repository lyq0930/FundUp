CREATE PROCEDURE CreateFund(IN usernameIn    VARCHAR(30), IN pidIn INT, IN fundAmountIn DECIMAL(10, 2),
                            IN paymentCardIn VARCHAR(30), OUT actualFunded DECIMAL(10, 2))
  BEGIN
    set @exceedFundAmount = (select  (fundSoFar + fundAmountIn) - P.maxFund from Project P where P.pid = pidIn);
    if @exceedFundAmount > 0
    then set fundAmountIn = fundAmountIn - @exceedFundAmount;
    end if;

    insert into Fund (username, pid, fundAmount, paymentCard)
    values (usernameIn, pidIn, fundAmountIn, paymentCardIn);

    update Project
    set fundSoFar = fundSoFar + fundAmountIn
    where pid = pidIn;

    set actualFunded = fundAmountIn;
  END;
