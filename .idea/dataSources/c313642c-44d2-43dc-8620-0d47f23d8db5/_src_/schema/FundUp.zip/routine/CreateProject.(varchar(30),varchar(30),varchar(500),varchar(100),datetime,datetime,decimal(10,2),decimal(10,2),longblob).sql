CREATE PROCEDURE CreateProject(IN usernameIn VARCHAR(30), IN pnameIn VARCHAR(30), IN pdescriptionIn VARCHAR(500),
                               IN tagsIn     VARCHAR(100), IN endFundTimeIn DATETIME, IN completionDateIn DATETIME,
                               IN minFundIn  DECIMAL(10, 2), IN maxFundIn DECIMAL(10, 2), IN media LONGBLOB)
  BEGIN
    insert into Project(pname, pdescription, pOwner, tags, endFundTime, completionDate, minFund, maxFund, cover, pstatus)
    values (pnameIn, pdescriptionIn, usernameIn, tagsIn, endFundTimeIn, completionDateIn,
            minFundIn, maxFundIn, media, 'Funding');
  END;
